import * as React from "react";
import { StyleSheet } from "react-nativescript";
import { getRelatedWords } from "../services/datamuseApi";

interface WordNodeProps {
  word: string;
  level: number;
  x: number;
  y: number;
}

export function WordNode({ word }: WordNodeProps) {
  const [relatedWords, setRelatedWords] = React.useState<string[]>([]);
  const [isExpanded, setIsExpanded] = React.useState(false);

  const handleTap = async () => {
    if (!isExpanded) {
      const words = await getRelatedWords(word);
      setRelatedWords(words);
      setIsExpanded(true);
    } else {
      setIsExpanded(false);
    }
  };

  return (
    <stackLayout style={styles.container}>
      <button
        style={[styles.wordButton, isExpanded && styles.expandedButton]}
        onTap={handleTap}
        text={word}
      />
      
      {isExpanded && (
        <scrollView orientation="horizontal" style={styles.scrollView}>
          <flexboxLayout style={styles.relatedContainer}>
            {relatedWords.map((relatedWord, index) => (
              <button
                key={`${relatedWord}-${index}`}
                style={styles.relatedWordButton}
                text={relatedWord}
                onTap={() => handleTap()}
              />
            ))}
          </flexboxLayout>
        </scrollView>
      )}
    </stackLayout>
  );
}

const styles = StyleSheet.create({
  container: {
    margin: 5,
    width: "100%",
  },
  wordButton: {
    fontSize: 16,
    padding: 10,
    minWidth: 100,
    backgroundColor: "#3b82f6",
    color: "white",
    borderRadius: 8,
    textAlignment: "center",
  },
  expandedButton: {
    backgroundColor: "#1d4ed8",
  },
  scrollView: {
    marginTop: 10,
    height: 60,
  },
  relatedContainer: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 10,
    gap: 10,
  },
  relatedWordButton: {
    fontSize: 14,
    padding: 8,
    minWidth: 80,
    backgroundColor: "#60a5fa",
    color: "white",
    borderRadius: 6,
    textAlignment: "center",
    margin: 5,
  }
});