import * as React from "react";
import { StyleSheet } from "react-nativescript";
import { FrameNavigationProp } from "react-nativescript-navigation";
import { RouteProp } from '@react-navigation/core';
import { MainStackParamList } from "../NavigationParamList";
import { WordExplorer } from "./WordExplorer";

type ScreenOneProps = {
    route: RouteProp<MainStackParamList, "One">,
    navigation: FrameNavigationProp<MainStackParamList, "One">,
};

export function ScreenOne({ navigation }: ScreenOneProps) {
    return (
        <stackLayout style={styles.container}>
            <label className="text-2xl font-bold text-center p-4">
                Word Explorer
            </label>
            <scrollView>
                <WordExplorer />
            </scrollView>
        </stackLayout>
    );
}

const styles = StyleSheet.create({
    container: {
        height: "100%",
    },
});