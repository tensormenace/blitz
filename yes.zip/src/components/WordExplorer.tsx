import * as React from "react";
import { StyleSheet } from "react-nativescript";
import { WordNode } from "./WordNode";

export function WordExplorer() {
  const startingWords = ["explore", "discover", "learn", "create", "innovate"];

  return (
    <stackLayout style={styles.container}>
      {startingWords.map((word, index) => (
        <WordNode
          key={word}
          word={word}
          level={0}
          x={0}
          y={0}
        />
      ))}
    </stackLayout>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 20,
    width: "100%",
  },
});