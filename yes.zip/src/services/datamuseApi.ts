interface WordResponse {
  word: string;
  score: number;
}

export async function getRelatedWords(word: string): Promise<string[]> {
  try {
    const response = await fetch(`https://api.datamuse.com/words?ml=${word}&max=5`);
    const data: WordResponse[] = await response.json();
    return data.map(item => item.word);
  } catch (error) {
    console.error('Error fetching related words:', error);
    return [];
  }
}